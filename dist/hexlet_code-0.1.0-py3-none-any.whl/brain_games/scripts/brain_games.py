#! /usr/bn/env python 

from brain_games.cli import welcome_user

def main():
	welcome_user()
